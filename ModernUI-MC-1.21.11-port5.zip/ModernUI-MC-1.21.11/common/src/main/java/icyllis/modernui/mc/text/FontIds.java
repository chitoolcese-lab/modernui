/*
 * Modern UI.
 * Copyright (C) 2019-2025 BloCamLimb. All rights reserved.
 *
 * Modern UI is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 */

package icyllis.modernui.mc.text;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;

import javax.annotation.Nonnull;

/**
 * Since 1.21.9, {@link Style#getFont()} returns a {@link FontDescription} instead of an identifier.
 */
public final class FontIds {

    private FontIds() {
    }

    @Nonnull
    public static Identifier of(@Nonnull Style style) {
        FontDescription description = style.getFont();
        if (description instanceof FontDescription.Resource resource) {
            return resource.id();
        }
        return Minecraft.DEFAULT_FONT;
    }
}
