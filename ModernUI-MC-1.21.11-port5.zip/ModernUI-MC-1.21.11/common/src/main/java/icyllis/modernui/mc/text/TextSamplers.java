/*
 * Modern UI.
 * Copyright (C) 2019-2025 BloCamLimb. All rights reserved.
 *
 * Modern UI is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 */

package icyllis.modernui.mc.text;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuSampler;

/**
 * Since 1.21.11, texture filtering lives in {@link GpuSampler}, not in the texture.
 */
public final class TextSamplers {

    private TextSamplers() {
    }

    /**
     * Nearest filtering, no mipmaps (bitmap text, effects, off-screen layers).
     */
    public static GpuSampler nearest() {
        return RenderSystem.getSamplerCache().getClampToEdge(FilterMode.NEAREST);
    }

    /**
     * Bilinear filtering with mipmaps (SDF text).
     */
    public static GpuSampler linearMipmap() {
        return RenderSystem.getSamplerCache().getSampler(
                AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE,
                FilterMode.LINEAR, FilterMode.LINEAR, true);
    }

    /**
     * Same as the old {@code GLFontAtlas.setLinearSampling()}.
     */
    public static GpuSampler forAtlas(boolean linear) {
        return RenderSystem.getSamplerCache().getSampler(
                AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE,
                linear ? FilterMode.LINEAR : FilterMode.NEAREST, FilterMode.NEAREST, linear);
    }
}
