/*
 * Modern UI.
 * Copyright (C) 2019-2023 BloCamLimb. All rights reserved.
 *
 * Modern UI is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * Modern UI is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with Modern UI. If not, see <https://www.gnu.org/licenses/>.
 */

package icyllis.modernui.mc.mixin;

import icyllis.modernui.mc.BlurHandler;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import javax.annotation.Nonnull;

@Mixin(Screen.class)
public class MixinScreen {

    //private static final Identifier BACKGROUND = new Identifier("textures/block/spruce_planks.png");

    /*@Shadow
    public int width;

    @Shadow
    public int height;

    @Shadow
    protected ItemRenderer itemRenderer;

    @Shadow
    @Nullable
    protected Minecraft minecraft;*/

    @Redirect(
            method = "renderTransparentBackground",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/GuiGraphics;fillGradient(IIIIII)V"
            )
    )
    private void renderBackgroundInWorld(@Nonnull GuiGraphics gr, int x1, int y1,
                                         int x2, int y2, int color1, int color2) {
        BlurHandler.INSTANCE.drawScreenBackground(gr, x1, y1, x2, y2);
    }

    /*@Redirect(
            method = "renderTooltipInternal",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/List;isEmpty()Z"
            ),
            remap = false
    )
    private boolean fakeEmpty(@Nonnull List<ClientTooltipComponent> list) {
        if (TooltipRenderer.sTooltip) {
            return true;
        }
        return list.isEmpty();
    }

    @Inject(method = "renderTooltipInternal", at = @At("TAIL"), remap = false)
    private void drawTooltip(PoseStack stack, List<ClientTooltipComponent> list, int x, int y, CallbackInfo ci) {
        if (TooltipRenderer.sTooltip && !list.isEmpty()) {
            assert minecraft != null;
            TooltipRenderer.drawTooltip(stack, list, x, y, font, width, height, itemRenderer, minecraft);
        }
    }*/

    /*@Redirect(
            method = "renderDirtBackground",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/texture/TextureManager;bind
                    (Lnet/minecraft/resources/Identifier;)V"
            )
    )
    private void bindDirtBackgroundTexture(@Nonnull TextureManager textureManager, Identifier rl) {
        textureManager.bind(BACKGROUND);
    }*/
}
