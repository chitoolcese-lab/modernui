# Port 1.21.8 -> 1.21.11 (pasada 1, SIN COMPILAR)

Esta pasada se hizo sin acceso a red ni al jar de Minecraft 1.21.11, asi que NADA esta compilado.
Es una base: compila, y manda los errores para seguir iterando.

## Hecho
- `ResourceLocation` -> `net.minecraft.resources.Identifier` (58 ficheros, incluidas cadenas de mixins/AT).
- `Window.getWindow()` -> `Window.handle()`.
- Pantallas (`SimpleScreen`/`MenuScreen` x4): `keyPressed/keyReleased(KeyEvent)`,
  `charTyped(CharacterEvent)`, `mouseClicked(MouseButtonEvent, boolean)`,
  `mouseReleased(MouseButtonEvent)`, `mouseDragged(MouseButtonEvent, dx, dy)`.
- `MixinKeyboardHandler` -> `keyPress(long, int, KeyEvent)`.
- `MixinMouseHandler` (fabric) -> `onButton(long, MouseButtonInfo, int)`.
- `MixinEditBox` (common): `keyPressed(KeyEvent)`, inyeccion en HEAD.
- `KeyMapping` -> usa `KeyMapping.Category` (+ clave `key.category.modernui.main` en en_us.json).
- Versiones: gradle.properties, fabric/build.gradle, fabric.mod.json, mods.toml, neoforge.mods.toml, pack.mcmeta.

## Verificar a mano (valores que puse sin poder comprobarlos)
- `forge_version=61.0.0`, `modmenu:17.0.0`, `forgeconfigapiport-fabric:21.11.1`.
- Version de `dev.architectury.loom` (1.11-SNAPSHOT puede no soportar 1.21.11).
- Nombres: `Window.handle()`, `KeyMapping.Category.register`, `KeyMapping.matches(KeyEvent)`,
  `EditBox.canConsumeInput()`, `Screen.hasControlDown()` estatico (UIManager, MixinEditBox, EventHandlers).

## Riesgo alto (mixins/accesos que casi seguro cambian; el error saldra al arrancar o compilar)
- Render GUI: MixinGuiRenderer, AccessGuiRendererDraw, MixinGuiTextRenderState, MixinGuiGraphics (x3),
  MixinGameRenderer, AccessGameRenderer, MixinRenderSystem (x3), AccessGpuTexture, AccessRenderType, AccessPostChain.
- Texto: MixinFontRenderer, AccessFontRenderer, MixinFontManager, MixinContextualBar, MixinClientTextTooltip.
- Mundo: MixinLevelRenderer, MixinLevelRendererDBG, MixinSignRenderer (1.21.9 rehizo el render de entidades/carteles).
- Forge/NeoForge: `EventHandler`/`UIManagerForge` (getters de `ScreenEvent.*`), `MixinScrollPanel`.
- Forge: `ObfuscationReflectionHelper.findField(..., "f_118468_")` (nombres SRG) en UIManagerForge.
- `accesstransformer.cfg` / `modernui.accesswidener`: revisar que los miembros sigan existiendo.

## Referencia
El fork mVUS (github.com/Tealeste/ModernUI-MC-mVUS, LGPL-3.0) ya porta 1.21.9-1.21.11 sobre ModernUI-MC 3.12.x;
sirve para comparar mixins concretos (base de codigo distinta a la 3.13 de este zip).

## Compilar
JDK 21: `./gradlew :ModernUI-Fabric:compileJava`, luego `:ModernUI-NeoForge:` y `:ModernUI-Forge:`.
